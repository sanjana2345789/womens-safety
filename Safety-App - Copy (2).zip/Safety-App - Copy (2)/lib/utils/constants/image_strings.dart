class ImageStrings
{
  //  -- App logos
  static const lightAppLogo = "assets/logos/logo.svg";
  static const darkAppLogo = "assets/logos/logo_dark_theme.svg";
  static const splashLogo = "assets/logos/splash_screen_logo.svg";
}